//
//  Filter.swift
//  HackChallenge
//
//  Created by Jessie Chen on 11/5/2021.
//

import UIKit

class Filter{
    var filterLabel: String
    
    init(label: String){
        self.filterLabel = label
    }
}
